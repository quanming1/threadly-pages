知序：183 个圆润实心图标 + 12 个封面/背景 SVG。
每份素材由内置 genImage 独立生成，再追踪轮廓为真正的矢量路径。生成原稿、提示词与哈希记录见 docs/visual-assets/generated-solid/。
所有 SVG 使用 fill=currentColor，细节为透明留白，无内嵌位图。图标 24×24；插图 160×104。React 使用 apps/web/src/visuals/Icon.tsx、icons.ts 或 VisualAsset.tsx，并通过 color 配色；外部 img 不会继承父级 CSS 颜色。
转换与复核说明见 docs/visual-assets/README.md。
